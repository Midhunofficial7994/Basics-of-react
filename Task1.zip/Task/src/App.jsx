import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import Home from "./Home";
import Props from "./Props"
// import Triiger from "./Triiger";
import Input from "./Input";


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />}></Route>

        <Route path="/Saved items" element={<Props />}></Route>  
        
        <Route path="+" element={<Input />}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;



